import java.util.Scanner;

public class Lab1PartTwo{
    public static void main (String[] args){
// 1)      System.out.println("My name is Englebert.");

// 2))        String lastname;
//        lastname = "Humperdinck";
//        System.out.println("My name is Englebert " + lastname);
        
// 3)        System.out.println("Christopher Mahadeo");

//4    Scanner keyboard = new Scanner(System.in);
//    String name = keyboard.nextLine();
//    System.out.println("My name is " + name);
        
// 5)        Scanner keyboard = new Scanner(System.in);
//        System.out.println("Hi, what's your name?");
        
//        String name = keyboard.nextLine();
//        System.out.println("Nice to meet you " + name + "!");
       
// 6)        System.out.println("Hi, what's your name?");
        
//        Scanner keyboard = new Scanner(System.in);
//        String nameInput = keyboard.nextLine();
        
//        String nameParsed = nameInput.substring(11);
        
//        System.out.println("Nice to meet you " + nameParsed + "!");
    }
}