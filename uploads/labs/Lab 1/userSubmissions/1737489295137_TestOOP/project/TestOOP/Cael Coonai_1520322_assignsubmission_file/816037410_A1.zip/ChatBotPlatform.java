/* COMP 2603 Assignment 1 */
/* Name: Cael Coonai      */
/* Student ID: 816037410  */

import java.util.ArrayList;

public class ChatBotPlatform {
    
    private ArrayList<ChatBot> bots;

    public ChatBot getBot(int botNumber) {return this.bots.get(botNumber);}

    ChatBotPlatform() {
        bots = new ArrayList<ChatBot>();
    }

    public boolean addChatBot(int LLMcode) {
        if (ChatBot.getTotalNumMessagesRemaining() == 0) {
            return false;
        }
        this.bots.add(new ChatBot(LLMcode));
        return true;
    }

    public String getChatBotList() {
        String result = "----------------------\n Your Chatbots\n";
        for (int i = 0; i < bots.size(); i++) {
            result += "Bot Number: " + i + ' ' + this.bots.get(i) + '\n';
        }
        result += "Total Messages Used: " +
            ChatBot.getTotalNumResponsesGenerated() + '\n';
        result += "Total Messages Remaining: " +
            (ChatBot.getTotalNumMessagesRemaining()) + '\n';
        result += "----------------------";

        return result;
    }

    public String interactWithBot(int botNumber, String message) {
        if (botNumber <  0 || botNumber >= this.bots.size()) {
            return
                "Incorrect Bot Number (" + botNumber + ") Selected. Try again";
        }
        return this.bots.get(botNumber).prompt(message);
    }

}