/* COMP 2603 Assignment 1 */
/* Name: Cael Coonai      */
/* Student ID: 816037410  */

import java.util.Random;

public class ChatBotSimulation {

    public static void main(String[] args) {
        System.out.println("Hello World!");

        ChatBotPlatform chatBotPlatform = new ChatBotPlatform();

        for (int llmCode = 0; llmCode <= 6; llmCode++) {
            chatBotPlatform.addChatBot(llmCode);
        }

        System.out.println(chatBotPlatform.getChatBotList());

        String prompt = "";
        Random rng = new Random();
        for (int it = 0; it < 15; it++) {
            String response = chatBotPlatform
                                .interactWithBot(rng.nextInt(8), prompt);
            System.out.println(response);
            prompt = response;
        }


        System.out.println(chatBotPlatform.getChatBotList());
    }

}
