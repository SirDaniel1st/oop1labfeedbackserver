/* COMP 2603 Assignment 1 */
/* Name: Cael Coonai      */
/* Student ID: 816037410  */

public class ChatBot {

    private String chatBotName;
    private int numResponsesGenerated;
    static private int messageLimit = 10;
    static private int messageNumber = 0;

    public String getChatBotName() {return chatBotName;}
    public int getNumResponsesGenerated() {return numResponsesGenerated;}
    public static int getMessageLimit() {return messageLimit;}
    public static int getMessageNumber() {return messageNumber;}

    ChatBot() {
        this.chatBotName = ChatBotGenerator.generateChatBotLLM(0);
    }

    ChatBot(int LLMCode) {
        this.chatBotName = ChatBotGenerator.generateChatBotLLM(LLMCode);
    }

    public static int getTotalNumResponsesGenerated() {
        return ChatBot.messageNumber;
    }

    public static int getTotalNumMessagesRemaining() {
        return ChatBot.messageLimit - ChatBot.messageNumber;
    }

    public static boolean limitReached() {
        return messageNumber == messageLimit;
    }

    private String generateResponse() {
        String demoResponse = "generatedTextHere";
        ChatBot.messageNumber++;
        this.numResponsesGenerated++;

        return
            "(Message# " + ChatBot.messageNumber + ") Response from " +
            this.chatBotName + "\t>> " + demoResponse;
    }

    public String prompt(String requestMessage) {
        if (ChatBot.messageNumber >= ChatBot.messageLimit) {
            return "Daily Limit Reached. Wait 24 hours to resume chatbot usage";
        }
        return generateResponse();
    }

    public String toString() {
        return
            "ChatBot Name: " + this.chatBotName +
            "\tNumber Messages Used: " + this.numResponsesGenerated;
    }

}