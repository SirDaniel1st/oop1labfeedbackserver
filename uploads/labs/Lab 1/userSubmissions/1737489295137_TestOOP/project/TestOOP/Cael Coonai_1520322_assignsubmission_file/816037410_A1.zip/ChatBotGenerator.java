/* COMP 2603 Assignment 1 */
/* Name: Cael Coonai      */
/* Student ID: 816037410  */

public class ChatBotGenerator {

    private static String[] llms = {
        "ChatGPT-3.5",
        "LLaMa",
        "Mistral7B",
        "Bard",
        "Claude",
        "Solar"
    };

    public static String getLlm(int index) {return llms[index];}

    public static String generateChatBotLLM(int LLMCodeNumber) {
        if (LLMCodeNumber < 0|| LLMCodeNumber >= ChatBotGenerator.llms.length) {
            return ChatBotGenerator.llms[0];
        }
        return ChatBotGenerator.llms[LLMCodeNumber];
    }

    public static String generateChatBotLLM(String botName) {
        return botName;
    }


}
